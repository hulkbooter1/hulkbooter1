#!/usr/bin/env python
import logging

import Bt
from Bt import *
# from talib import *
from binance.um_futures import UMFutures
from binance.lib.utils import config_logging
from binance.error import ClientError
from config import *
from Config2 import *
from modules import *
# from Utilidades import *
# from crisp_alpha_vantage.technical_indicators import * as tis
# from utils1 import *
# import datetime as dt
import tti.indicators as ti
import pandas as pd
from pandas_datareader import data as pdr
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.ticker as mticker
import datetime as datetime
import numpy as np
from mpl_finance import candlestick_ohlc
import time
import pytz

config_logging(logging, logging.DEBUG)

Bot = Cripto_Bot(api_key=api_key_f, api_secret=api_secret_f, cripto=CRIPTO, ref=REF, contractType=contractType,
                 period=intervalo, leverage=LEVERAGE, capital=CAPITAL, side=SIDE, sma_f=sma_f,
                 sma_s=sma_s)

Bot.run()
