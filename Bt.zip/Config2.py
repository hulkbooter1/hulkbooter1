

# Variables
REF = 'USDT'
CRIPTO = 'LINK'
CAPITAL = 2
POSITION_SIDE='LONG'
par = 'LINKUSDT'
contractType = 'PERPETUAL'
intervalo = '15m'
Price = 0.00000
Precio_Entrada = 0.00000
Precio_Liq = 0.00000
Account_info = []
Moneda = 'USDT'
FBalance = 0.00000
minQty =0.00000
stepSize =0.00000
maxQty =0.00000
LEVERAGE = 5
limit = 500
SIDE='LONG'
sma_f = 9
sma_s= 26
rsi_periodo=14
macd_k=0.0
macd_d=0.0
rsi=0.0
sma_100=0.0