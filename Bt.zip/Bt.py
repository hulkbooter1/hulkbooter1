import binance.um_futures
#from Utilidades import *
from modules import *
from Config2 import *
import time
import datetime as dt
import pytz

class Cripto_Bot():

    def __init__(self, api_key,api_secret,cripto, ref, period, leverage,contractType,capital, side, sma_f, sma_s):
        self.client = UMFutures(key=api_key, secret=api_secret)
        #
        try:
            self.client.change_position_mode(dualSidePosition=True)
        except:
            print('error changin position mode')
            pass

        # set parametros
        self.cripto = cripto
        self.ref = ref
        self.exchange = self.cripto + self.ref
        self.side = side
        #self.pside= side
        self.contractType =contractType
        self.market_price=0.0
        self.single_operation_capital = capital
        self.leverage = leverage
        #self.capital = ''
        #self.InvCapital=capital
        self.SMA_F = sma_f
        self.SMA_S = sma_s
        self.period = period

        try:
            chng_leverage = self.client.change_leverage(par, LEVERAGE, recvWindow=6000)
            #chng_leverage=self.client.change_leverage(par,LEVERAGE, recvWindow=6000)#change_leverage(symbol=self.exchange, leverage=self.leverage)
            print('leverage has changed')
        except:
            self.RUN = False
            print('Error leverage')




        # Variables funcionales
        """respuesta de una orden {'orderId': 0, 'symbol': '', 'status': '', 'clientOrderId': '',
         'price': '', 'origQty': '', 'executedQty': '', 'cumQuote': '',
          'timeInForce': '', 'type': '', 'reduceOnly': False, 
          'closePosition': False, 'side': '', 'stopPrice': '', 'priceProtect': False,
           'origType': '', 'updateTime': 0}"""

        self.stopLoss= self.market_price + (self.market_price * 0.01)
        self.rsi=0.0
        self.macd=0.0
        self.macd_s=0.0
        self.stoch_k=0.0
        self.stoch_d=0.0
        
        # Filtros

        result = self.client.exchange_info()
        self.minQty, self.stepSize, self.maxQty = Get_Exchange_filters(result, self.exchange)

        self.maxDeciamlQty = Calculate_max_Decimal_Qty(self.stepSize)

        self.capital = Get_Capital(self.client.account(recvWindow=6000), self.ref)

        # Variables logisticas

        self.df = pd.DataFrame(columns=['time', 'open', 'high', 'low', 'close', 'volume', 'start', 'SMA_F', 'SMA_S'])

        self.buysignal = None
        self.sellsignal = None

        self.quantity = None
        self.open = False

        self.RUN = True

    def Orderls(self,side,price):
        Qty = Calculate_Qty(price, self.single_operation_capital * self.leverage, self.minQty, self.maxQty,
                            self.maxDeciamlQty)
        if not Qty:
            self.RUN = False
        if self.side == 'LONG':
            if side == 'BUY':
                self.quantity = Qty
                self.open = True
            else:
                self.open = False
        else:
            if side == 'SELL':
                self.quantity = Qty
                self.open = True
            else:
                self.open = False

        responss=self.client.new_order(symbol=self.exchange, side=side, type='MARKET', quantity=self.quantity,
                               positionSide=self.side)

        #    respose = um_futures_client.new_order(symbol=self.cripto+self.ref, side=side,type="LIMIT",quantity=cantidad,timeInForce="GTC",
                                          # stopPrice=stop_loss,workingType="MARK_PRICE",priceProtect="TRUE",price=5.4)



    def Last_data(self):

        if self.df.shape[0] == 0:
            #candles = self.client.get_candlestick_data(symbol=self.exchange, interval=self.period,limit=self.SMA_S + 1)
            candles = self.client.continuous_klines(pair=self.exchange, contractType=contractType, interval=self.period, limit=self.SMA_S + 1)
            self.df1 = Get_RDF(candles)
            self.df = Parse_data1(candles, limit=self.SMA_S+1)

        else:

            #candles = self.client.get_candlestick_data(symbol=self.exchange, interval=self.period,limit=self.SMA_S + 1)
            candles = self.client.continuous_klines(pair=self.exchange, contractType=contractType,interval=self.period, limit=self.SMA_S + 1)
            self.df1 = Get_RDF(candles)
            """
            df_temp = Parse_data1(candles, limit=1)
            self.df = self.df.append(df_temp, ignore_index=True)
            self.df.drop(index=0, inplace=True)
            self.df.index = list(range(self.SMA_S + 1))


        self.df['SMA_F'] = self.df['close'].rolling(self.SMA_F).mean()
        self.df['SMA_S'] = self.df['close'].rolling(self.SMA_S).mean()


        
        if self.pside == 'LONG':
            self.buysignal = Crossover(self.df.SMA_F.values[-2:], self.df.SMA_S.values[-2:])
            self.sellsignal = Crossover(self.df.SMA_S.values[-2:], self.df.SMA_F.values[-2:])
        else:

            self.buysignal = Crossover(self.df.SMA_S.values[-2:], self.df.SMA_F.values[-2:])
            self.sellsignal = Crossover(self.df.SMA_F.values[-2:], self.df.SMA_S.values[-2:])
        """
        if self.side == 'LONG':
            self.buysignal = Crossover(self.df1.EMA_9.values[-2:], self.df1.EMA_26.values[-2:])
            self.sellsignal = Crossover(self.df1.EMA_26.values[-2:], self.df1.EMA_9.values[-2:])
        else:

            self.buysignal = Crossover(self.df1.EMA_26.values[-2:], self.df1.EMA_9.values[-2:])
            self.sellsignal = Crossover(self.df1.EMA_9.values[-2:], self.df1.EMA_26.values[-2:])

    def Single_Operation(self):
        self.capital = Get_Capital(self.client.account(), self.ref)
        if float(self.capital) <= self.single_operation_capital:
            print('Dinero no suficiente')
            self.RUN = False
        # actualizar datos
        self.Last_data()

        # precio actual
        #price = self.client.price_ticker(symbol=self.exchange)[0].price
        price= Price_Market(self.exchange)
        if self.open:
            if self.sellsignal:
                if self.side == 'LONG':
                    side = 'SELL'
                    try:
                        self.Order(side=side, price=price)
                    except Exception as e:
                        print(e)

                else:
                    side = 'BUY'
                    try:
                        self.Order(side=side, price=price)
                        self.H_df.operacion.iloc[-1] = 'BUY'
                    except Exception as e:
                        print(e)
        else:
            if self.buysignal:
                if self.side == 'LONG':
                    side = 'BUY'
                    try:
                        self.Order(side=side, price=price)
                    except Exception as e:
                        print(e)
                else:
                    side = 'SELL'
                    try:
                        self.Order(side=side, price=price)

                    except Exception as e:
                        print(e)

    def run(self):
        if 'm' in self.period:
            if len(self.period) == 2:
                step = int(self.period[0])
            else:
                step = int(self.period[:2])
        elif self.period == '15m':
            step = 15
        else:
            print('interval error')
            return
        self.Last_data()
        START = self.df.start.iloc[-1] + dt.timedelta(minutes=step)
        print(START)
        while dt.datetime.now(dt.timezone.utc) < pytz.UTC.localize(START):
            time.sleep(1)
            pass
            print('Strarting Bot...\n')
        time.sleep(3)  # para ser seguros de encontrar los datos de la velas siguente
        print('Bot started')
        while self.RUN:
            temp = time.time()
            self.Single_Operation()
            retraso = time.time() - temp
            time.sleep(60 * step - retraso)

