import pandas as pd
import pytz
import tti.indicators as ti
from dateutil import parser
import numpy as np
from binance.um_futures import UMFutures
from config import *

key = api_key_f
secret = api_secret_f

um_futures_client = UMFutures(key=key, secret=secret)

def Get_Capital(data,ref):
    #Ac_info = um_futures_client.account(recvWindow=6000)
    for i in range(len(data['assets'])):
        if data['assets'][i]['asset'] == ref:
           Ainfo = data['assets'][i]['marginBalance']
           #print("Margin Balance: "+str(Ainfo))
    return Ainfo

def Get_Ex_Info(par):
    Ex_info = um_futures_client.exchange_info()
    for i in range(len(Ex_info['assets'])):
        if Ex_info['assets'][i]['asset'] == par:
           Einfo = Ex_info['assets'][i]['marginBalance']
           print("Margin Balance: "+str(Einfo))
    return Einfo

def Get_RDF(data):
    idf = pd.DataFrame(data, columns=['Open Time', 'Open', 'High', 'Low', 'Close', 'Volume', 'Close Time', 'Quote asset volume', 'Number of Trades', 'Taker Buy Base Asset Volume', 'Taker Buy Quote Asset Volume', 'Nothing'])
    df = pd.DataFrame(idf, columns=['open', 'high', 'low', 'close', 'volume', 'close time'])
    df['Datetime'] = pd.DatetimeIndex(pd.to_datetime(idf['Close Time'], unit='ms'))
    df['Open']=idf.Close
    df['High'] = idf['High'].astype('float')
    df['Low'] = idf['Low'].astype('float')
    df['Close'] = idf['Close'].astype('float')
    df['Volume'] = idf['Volume'].astype('float')
    df['Close Time'] = pd.DatetimeIndex(pd.to_datetime(idf['Close Time'], unit='ms'))
    df = df.set_index('Datetime')
    ema9 = sma(data=data, sma_period=9, ma_type='exponential')
    ema26 = sma(data=data, sma_period=26, ma_type='exponential')
    ema_9 = ema9[1]['ma-exponential']
    ema_26 = ema26[1]['ma-exponential']
    df = df.assign(EMA_9=ema_9)
    df = df.assign(EMA_26=ema_26)
    return df
def Get_Exchange_filters(result,par):
    for i in range(len(result['symbols'])):
        if result['symbols'][i]['symbol'] == par:
            minQty = float(result['symbols'][i]['filters'][2]['minQty'])
            stepSize = float(result['symbols'][i]['filters'][2]['stepSize'])
            maxQty = float(result['symbols'][i]['filters'][2]['maxQty'])

            return minQty, stepSize, maxQty

def Calculate_max_Decimal_Qty(stepSize):
    max_decimal_quantity=0
    a = 10
    while stepSize*a<1:
      a = a*10**max_decimal_quantity
      max_decimal_quantity += 1
    return max_decimal_quantity
def Calculate_Qty(price, money, minQty, maxQty, maxDeciamlQty):

    Q = money / price
    if (Q < minQty or Q > maxQty):
        return False
    Q = np.round(Q, maxDeciamlQty)
    return Q

def sma(data, sma_period, ma_type):
    #df = df.assign(EMA_9=ema_9)
    data_h = get_dataKL(data)
    dfma = pd.DataFrame(data_h.close)
    ma =ti.MovingAverage(input_data=dfma, period=sma_period,ma_type=ma_type)
    return [ma.getTiValue(), ma.getTiData()]

def Price_Market(par):
    mprice = um_futures_client.mark_price(par)
    MP= mprice['markPrice']
    return float(MP)

def get_dataKL(cnd):

    df = pd.DataFrame(cnd, columns=['Open Time', 'Open', 'High', 'Low', 'close', 'Volume', 'Close Time', 'Quote asset volume', 'Number of Trades', 'Taker Buy Base Asset Volume', 'Taker Buy Quote Asset Volume', 'Nothing'])
    # Dar formato de fecha en milisegundos a las columnas "Open Time" y "Close Time"
    df['Datetime'] = pd.DatetimeIndex(pd.to_datetime(df['Close Time'], unit='ms'))
    df['Date'] = df['Open Time'].apply(pd.to_numeric)
    df['Close Time'] = pd.to_datetime(df['Close Time'], unit='ms')

    # Mantener las demás columnas como números flotantes
    columnas_numericas = ['Open', 'High', 'Low', 'close', 'Volume', 'Quote asset volume', 'Taker Buy Base Asset Volume', 'Taker Buy Quote Asset Volume']
    df[columnas_numericas] = df[columnas_numericas].astype(float)
    df = df.set_index('Datetime')

    # Eliminar advertencias de fillna

    return df

def Parse_data1(result, limit):
    """
    :param result:
    :param limit:
    :return:
    """
    data = []
    for i in range(limit):
        vela = []
        vela.append(result[i][0])
        vela.append(result[i][1])
        vela.append(result[i][2])
        vela.append(result[i][3])
        vela.append(result[i][4])
        vela.append(result[i][5])
        data.append(vela)
    df1 = pd.DataFrame(data)
    col_names = ['time', 'open', 'high', 'low', 'close', 'volume']
    df1.columns = col_names
    for col in col_names:
        df1[col] = df1[col].astype(float)
    df1['start'] = pd.to_datetime(df1['time'] * 1000000)

    return df1

def Crossover(MF, MS):
    if (MF[0] < MS[0] and MF[1] >= MS[1]):
        return True
    else:
        return False